﻿using System;

namespace NOVO.Models
{
    public enum RepairStatus
    {
        NotStarted = 0,
        InProgress = 1,
        Complete = 2
    }
    public class VehicleRepairsQueue
    {
        public Guid Id { get; set; }
        public Guid VehicleId { get; set; }
        public RepairStatus Status { get; set; }
    }
}
