﻿using System;

namespace NOVO.Models
{
    public class VehicleInspectionQueue
   {
        public Guid Id { get; set; }
        public Guid VehicleId { get; set; }
   }
}
