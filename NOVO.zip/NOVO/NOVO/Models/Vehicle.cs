﻿using System;

namespace NOVO.Models
{
    public enum VehicleType
    {
        Car = 1,
        Motorcycle = 2
    }
    public class Vehicle
    {
        public Guid Id { get; set; }
        public string Model { get; set; }
        public string Make { get; set; }
        public VehicleType Type { get; set; }
        public bool AccelerationTest { get; set; }
        public bool DecelerationTest { get; set; }
        public bool BothTest { get; set; }
    }
}
