﻿using NOVO.Models;

namespace NOVO.Services.Factory
{
    public static class VehicleFactory
    {
        public static IVehicle GetVehicleTypeObject(VehicleType type)
        {
            IVehicle objVehicle = null;
            if (type == VehicleType.Car)
            {
                objVehicle = new Car();
            }
            else if (type == VehicleType.Motorcycle)
            {
                objVehicle = new Motorcycle();
            }

            return objVehicle;
        }
    }
}
