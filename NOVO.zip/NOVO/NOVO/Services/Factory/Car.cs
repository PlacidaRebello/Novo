﻿using NOVO.Models;
using NOVO.Services.Strategy;
using System;

namespace NOVO.Services
{
    public class Car : IVehicle
    {
        StrategyContext context;
        public bool Inspect(Vehicle vehicle)
        {
            //chain of responsibility design pattern can be used to carry out multiple tests for offered services so repeated If Else can be avoided 
            //But right now it feels over engineering
            if (vehicle.AccelerationTest)
            {
                //template pattern implemented here
                Acceleration accelerationTest = new Acceleration();
                return accelerationTest.RunTest(vehicle);
            }
            if (vehicle.DecelerationTest)
            {
                //strategy pattern implemented here 
                context = new StrategyContext(new Deceleration());
                return context.TestStrategy(vehicle);
            }
            else
            {
                Both bothTest = new Both();
                return bothTest.RunTest(vehicle);
            }
        }

        public void Repair(Vehicle vehicle)
        {
            //Add it to repair queue
            //complete repairs
            //Add it to inspection queue
            Console.WriteLine("Vehicle Repaired and added to Inspection");
        }

        public void DisplayResult(Vehicle vehicle)
        {
            Console.WriteLine("Display Results");
        }        
    }
}
