﻿using NOVO.Models;
using System;

namespace NOVO.Services
{
    class Motorcycle : IVehicle
    {
        public bool Inspect(Vehicle vehicle)
        {
            throw new NotImplementedException();
        }

        public void Repair(Vehicle vehicle)
        {
            throw new NotImplementedException();
        }

        public void DisplayResult(Vehicle vehicle)
        {
            throw new NotImplementedException();
        }      
    }

}
