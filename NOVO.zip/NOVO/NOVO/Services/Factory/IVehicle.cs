﻿using NOVO.Models;

namespace NOVO.Services
{
    public interface IVehicle
    {
        bool Inspect(Vehicle vehicle);
        void Repair(Vehicle vehicle);
        void DisplayResult(Vehicle vehicle);
    }
}
