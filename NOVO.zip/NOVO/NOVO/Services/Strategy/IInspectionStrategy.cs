﻿using NOVO.Models;

namespace NOVO.Services
{
    public interface IInspectionStrategy
    {
        bool RunTest(Vehicle vehicle);
    }
}
