﻿using NOVO.Models;
using System;

namespace NOVO.Services
{
    public class Deceleration : IInspectionStrategy
    {
        public bool RunTest(Vehicle vehicle)
        {
            var simulation = new Random();
            var result = simulation.Next(1, 2);
            if (result == 1)
            {
                Console.WriteLine("Deceleration Test Completed");
                return true;
            }
            return false;
        }
    }
}
