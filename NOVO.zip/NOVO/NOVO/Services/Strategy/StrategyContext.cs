﻿using NOVO.Models;

namespace NOVO.Services.Strategy
{
    public class StrategyContext
    {
        private IInspectionStrategy _strategy;
        public StrategyContext(IInspectionStrategy strategy)
        {
            this._strategy = strategy;
        }

        public bool TestStrategy(Vehicle vehicle)
        {
            return _strategy.RunTest(vehicle);
        }
    }
}
