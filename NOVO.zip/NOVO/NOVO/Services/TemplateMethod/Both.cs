﻿using NOVO.Models;

namespace NOVO.Services
{
    public class Both : Inspection
    {
        public override bool RunTest(Vehicle vehicle)
        {
            Deceleration objDeceleration = new Deceleration();
            var accelerationResult = objDeceleration.RunTest(vehicle);
            Acceleration objAcceleration = new Acceleration();
            var decelerationResult = objAcceleration.RunTest(vehicle);

            if (accelerationResult & decelerationResult)
            {
                TestPass(vehicle);
                return true;
            }

            TestFail(vehicle);
            return false;
        }

    }
}
