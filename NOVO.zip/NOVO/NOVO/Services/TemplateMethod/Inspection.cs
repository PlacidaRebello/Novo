﻿using NOVO.Models;
using System;

namespace NOVO.Services
{
    public abstract class Inspection
    {
        public abstract bool RunTest(Vehicle vehicle);

        public virtual void TestPass(Vehicle vehicle)
        {
            //Return Vehicle
            Console.WriteLine("Vehicle1 Passed Test and returned");            
        }
        public virtual void TestFail(Vehicle vehicle)
        {
            //Send to Repair
        }
    }
}
