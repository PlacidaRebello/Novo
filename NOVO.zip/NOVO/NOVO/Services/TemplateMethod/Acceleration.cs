﻿using NOVO.Models;
using System;

namespace NOVO.Services
{
    public class Acceleration : Inspection
    {
        public override bool RunTest(Vehicle vehicle)
        {
            var simulation = new Random();
            var result = simulation.Next(1, 2);
            if (result == 1)
            {                
                Console.WriteLine("AccelerationTest Completed");
                TestPass(vehicle);
                return true;
            }

            TestFail(vehicle);
            return false;
        }
    }
}
