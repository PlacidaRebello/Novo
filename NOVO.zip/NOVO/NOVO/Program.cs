﻿using NOVO.Models;
using NOVO.Services.Factory;
using System;

namespace AccelAuto
{
    class Program
    {
        
        static void Main(string[] args)
        {
            //Testing the Template Pattern
            Console.WriteLine("Testing Template Pattern");

            var vehicle1 = new Vehicle();
            vehicle1.Type = VehicleType.Car;
            vehicle1.AccelerationTest = true;
           
            //Start Inspection
            var vehicle = VehicleFactory.GetVehicleTypeObject(vehicle1.Type);
            vehicle.Inspect(vehicle1);

            //Show Result
            vehicle.DisplayResult(vehicle1);


            //Testing the Strategy Pattern
            Console.WriteLine("Testing Strategy Pattern");

            var vehicle2 = new Vehicle();
            vehicle2.Type = VehicleType.Car;
            vehicle2.DecelerationTest = true;

            var objVehicle = VehicleFactory.GetVehicleTypeObject(vehicle2.Type);
            var inspectionPassed = objVehicle.Inspect(vehicle2);                       

            if (inspectionPassed)
            {   
                //Return the vehicle
                Console.WriteLine("Deceleration Test Passed and Vehicle2 returned");                
            }
            else
            {
                //Add to Repair queue
                vehicle.Repair(vehicle2);
            }
            //Show Result
            vehicle.DisplayResult(vehicle2);
            Console.Read();
        }
    }
}




